
/**
 * TO CHANGE IMAGES: Use the "Studio Mode" in the app (gear icon) or replace these defaults.
 */
export const DEFAULT_IMAGES = {
  LOGO: "https://lh3.googleusercontent.com/aida-public/AB6AXuCQ5d8r53jO1bkfWU2gPRmQ56uR6q8GlF_WSCKB6YqhZzRNfkPnX2QFJTC0wPyI8WQslCT40z8MGLw80k8Jfnl3_xqL5qMXBMtflitsbLX-NFmS6QaCKAdiiTshAu5goyeKsJXUcx6YZsPCDL26ev43AZGiOGX98BeE0bvQRMevHnLKbRaLRfXuvBExnBrjNsUse7TUyKgi7bw2eSlrANAeFuzeO0dCrElH3zPAszOGKb8l6mYGLoakKOSquYvGmAl_NYzyWIs4_HQ",
  HERO: "https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&q=80&w=1200",
  ABOUT: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&q=80&w=800",
  SERVICE_MUDAS: "https://images.unsplash.com/photo-1524350876685-274059332603?auto=format&fit=crop&q=80&w=800",
  SERVICE_BIOINSUMOS: "https://images.unsplash.com/photo-1589923188900-85dae523342b?auto=format&fit=crop&q=80&w=800",
  SERVICE_CAFES: "https://images.unsplash.com/photo-1447933601403-0c6688de566e?auto=format&fit=crop&q=80&w=800",
  SERVICE_AGROFLORESTA: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&q=80&w=800",
  TARGET_AUDIENCE: "https://images.unsplash.com/photo-1592982537447-7440770cbfc9?auto=format&fit=crop&q=80&w=800",
  VISION: "https://images.unsplash.com/photo-1500651230702-0e2d8a49d4ad?auto=format&fit=crop&q=80&w=1200",
  PATTERN: "https://www.transparenttextures.com/patterns/p6.png",
  TESTIMONIAL_1: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200",
  TESTIMONIAL_2: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=200",
};

export const CONTACT_WHATSAPP = "https://wa.me/5500000000000";
